#include <stdio.h>
#include <gtk/gtk.h>

int main()
{

    printf("Compiled");

    return 0;
}