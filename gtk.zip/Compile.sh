#!/bin/bash

gcc Main.c -o Main `pkg-config --cflags --libs gtk+-3.0`

if test -f ~/Desktop/C-C++-Development/Main; then
    ./Main
fi